import tensorflow
assert tensorflow.__version__ == "2.12.0"
